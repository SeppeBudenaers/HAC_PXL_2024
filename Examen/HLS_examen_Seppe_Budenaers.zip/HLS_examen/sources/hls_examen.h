#ifndef HLS_EXAMEN_H
#define HLS_EXAMEN_H
	void ImageTransform(unsigned char* imageRGBA,unsigned char* ouput,int centerX, int centerY);
#endif
